# 💧 HydraDetectAI

Sistema de **detección de anomalías hidráulicas (golpe de ariete / bypass)** ejecutado directamente sobre **Arduino App Lab**, con inferencia local mediante un modelo Random Forest previamente entrenado.

El usuario sube un modelo `.joblib` y una señal de presión en `.csv` desde el navegador, y el backend ejecuta todo el pipeline (extracción de características + predicción) sin depender de la nube.

---

## 🎯 Objetivo

Detectar en tiempo casi real si una señal de presión en una tubería corresponde a:

- ✅ **NORMAL** — operación estándar del sistema.
- ⚠️ **BYPASS** — anomalía detectada (posible fuga, válvula abierta indebidamente o manipulación del circuito).

Toda la inferencia ocurre **en el dispositivo**, sin enviar datos sensibles a servidores externos.

---

## 🧩 Arquitectura

```
┌─────────────────────────┐     Multipart FormData     ┌──────────────────────────────┐
│  Navegador (index.html) │ ─────────────────────────▶ │  Backend FastAPI + WebUI     │
│  - Sube modelo .joblib  │                            │  (ejecutándose en Arduino)   │
│  - Sube señal .csv      │ ◀──────────── JSON ─────── │  - Parseo CSV                │
└─────────────────────────┘                            │  - Extracción de features    │
                                                       │  - Inferencia Random Forest  │
                                                       └──────────────────────────────┘
```

- **Frontend:** HTML + CSS + JS puro, servido por el propio Arduino.
- **Backend:** Python sobre FastAPI (vía `arduino.app_bricks.web_ui`).
- **Modelo:** Random Forest serializado con `joblib`, opcionalmente con `StandardScaler` y lista de `feature_names`.

---

## 🔬 Pipeline de procesamiento

Cuando llega una señal, el backend ejecuta en orden:

1. **Lectura** de los archivos multipart (`model_file`, `csv_file`).
2. **Deserialización** del modelo con `joblib`.
3. **Parseo** del CSV y detección automática de las columnas de tiempo y presión.
4. **Cálculo de la frecuencia de muestreo** (`fs`) a partir de los deltas temporales.
5. **Extracción de características:**
   - Baseline, amplitud de pico y tiempo al pico.
   - Constante de decaimiento exponencial (`decay_tau`) vía `scipy.optimize.curve_fit`.
   - Energía total y bandas espectrales (0–20, 20–100, 100–500, 500–1000 Hz) vía FFT.
   - Frecuencia dominante.
   - Energía por nivel de descomposición wavelet (`db4`, 4 niveles).
6. **Escalado opcional** con el `StandardScaler` del modelo.
7. **Predicción** + cálculo de confianza con `predict_proba`.
8. **Respuesta JSON** al frontend con etiqueta, confianza, `fs` y número de muestras.

---

## 📁 Estructura del proyecto

```
HydraDetectAI/
├── main.py              # Backend: endpoints /api/ping y /api/analyze
├── index.html           # Frontend: carga de archivos y visualización de resultados
├── requirements.txt     # Dependencias Python
└── README.md            # Este archivo
```

---

## ⚙️ Requisitos

### Hardware
- Placa compatible con **Arduino App Lab** (por ejemplo Portenta X8 o similar con entorno Linux embebido).

### Dependencias Python
```
numpy
pandas
joblib
scipy
pywavelets
python-multipart
```

> ⚠️ **Importante:** FastAPI requiere específicamente `python-multipart` (no `multipart`, que es una librería distinta). Si el entorno tiene `multipart` preinstalado, debe desinstalarse antes.

---

## 🚀 Puesta en marcha

1. Clonar o subir el proyecto al Arduino App Lab.
2. Verificar que `requirements.txt` incluye `python-multipart`.
3. Arrancar la app desde el panel de App Lab.
4. Abrir en el navegador la IP del dispositivo (por ejemplo `http://arduinito.local/`).
5. Subir:
   - El archivo **`.joblib`** con el modelo entrenado.
   - El archivo **`.csv`** con la señal de presión (columnas de tiempo y presión).
6. Pulsar **"Subir y Analizar"** y ver el resultado.

---

## 🔌 Endpoints expuestos

| Método | Ruta            | Descripción                                           |
|--------|-----------------|-------------------------------------------------------|
| GET    | `/api/ping`     | Diagnóstico: versiones de Python, numpy, pandas, etc. |
| POST   | `/api/analyze`  | Recibe `model_file` + `csv_file`, devuelve predicción.|

### Respuesta exitosa (`/api/analyze`)
```json
{
  "status": "success",
  "prediction": 1,
  "label": "BYPASS",
  "confidence": 94.3,
  "fs_hz": 1000,
  "n_samples": 2048
}
```

### Respuesta de error
```json
{
  "status": "error",
  "message": "Descripción legible del problema",
  "step": "paso_del_pipeline_donde_falló",
  "traceback": "..."
}
```

---

## 📊 Formato esperado del CSV

El archivo debe tener al menos **dos columnas numéricas**:

- Una de **tiempo** (en segundos), detectada por contener `t` o `time` en el nombre.
- Una de **presión**, detectada por contener `p`, `pres` o `bar` en el nombre.

Ejemplo:

```csv
time,pressure_bar
0.000,2.01
0.001,2.03
0.002,2.08
...
```

Si no se encuentran nombres reconocibles, el sistema usa las dos primeras columnas por defecto. Se requiere un mínimo de **10 muestras**.

---

## 📦 Formato esperado del modelo `.joblib`

El archivo puede ser:

- Un **diccionario** con las claves:
  - `models`: dict con la clave `rf` → modelo Random Forest entrenado (también acepta `rf` en la raíz).
  - `scaler` *(opcional)*: un `StandardScaler` ajustado.
  - `feature_names` *(opcional)*: lista con el orden de las features.
- O directamente el **objeto del modelo** (sin diccionario envolvente).

---

## 🛠️ Diagnóstico

El frontend incluye un panel de **"Ver diagnóstico completo"** que aparece automáticamente cuando ocurre un error. Muestra:

- Código HTTP de la respuesta.
- Paso exacto del pipeline donde falló.
- Traceback completo de Python.
- Fragmento del JSON crudo recibido.

Esto permite depurar sin tener que abrir los logs del Arduino.

---

## 📝 Licencia

MPL-2.0

---

## 👤 Autor

Andy Casafranca





# SPDX-License-Identifier: MPL-2.0
"""
Backend Arduino Q para análisis de transientes hidráulicos (waterhammer).

Carga un .joblib con modelos de scikit-learn (RandomForest y/o SVM) y
predice si una señal cargada en CSV corresponde a un estado Normal o
a un Bypass clandestino.

  • Si el .joblib tiene AMBOS modelos → predice con los dos y devuelve
    un consenso (campos `agreement` y `models` con el detalle de cada uno).
  • Si tiene solo uno → se usa ese modelo.
"""
from arduino.app_utils import App, Logger
from arduino.app_bricks.web_ui import WebUI
from fastapi import UploadFile, File
import os, io, traceback as tb
import numpy as np
import pandas as pd
import joblib
import scipy
from scipy.optimize import curve_fit
from scipy.fft import rfft, rfftfreq
import pywt
import xgboost
import lightgbm


logger = Logger("waterhammer-edge")

# =====================================================================
# EXTRACCIÓN DE CARACTERÍSTICAS
# =====================================================================
def extract_features(t, p, fs):
    features = {}
    p0 = np.median(p[:max(1, int(0.05 * len(p)))])
    features['baseline'] = float(p0)

    peak_idx = int(np.argmax(p))
    features['peak_amp'] = float(p[peak_idx] - p0)
    features['t_peak'] = float(t[peak_idx]) if len(t) > 0 else 0.0

    # RMS y crest factor (requeridos por los modelos de HydroAnalyzer v3.0)
    rms = float(np.sqrt(np.mean((p - p0) ** 2)))
    features['rms']   = rms
    features['crest'] = float(np.max(np.abs(p - p0)) / (rms + 1e-9))

    # Decaimiento exponencial
    try:
        idx_fit = (t >= t[peak_idx]) & (t <= t[peak_idx] + 1.0)
        if np.sum(idx_fit) > 10:
            env = np.abs(p[idx_fit] - p0)
            env[env <= 1e-6] = 1e-6
            def expo(x, a, tau): return a * np.exp(-(x - t[peak_idx]) / tau)
            popt, _ = curve_fit(expo, t[idx_fit], env, p0=[env[0], 0.3], maxfev=5000)
            features['decay_tau'] = float(max(popt[1], 1e-3))
        else:
            features['decay_tau'] = 0.0
    except Exception:
        features['decay_tau'] = 0.0

    # FFT y bandas de energía
    N = len(p)
    if N > 1:
        yf = np.abs(rfft(p - p0))
        xf = rfftfreq(N, 1.0 / fs)
        features['energy_total'] = float(np.sum(yf ** 2))
        for (a, b) in [(0, 20), (20, 100), (100, 500), (500, 1000)]:
            mask = (xf >= a) & (xf < b)
            features[f'energy_band_{a}_{b}'] = float(np.sum(yf[mask] ** 2)) if np.any(mask) else 0.0
        features['dom_freq'] = float(xf[np.argmax(yf)]) if len(xf) > 0 else 0.0
    else:
        features['energy_total'] = 0.0
        features['dom_freq'] = 0.0
        for (a, b) in [(0, 20), (20, 100), (100, 500), (500, 1000)]:
            features[f'energy_band_{a}_{b}'] = 0.0

    # Wavelets
    try:
        coeffs = pywt.wavedec(p - p0, 'db4', level=4)
        for i, c in enumerate(coeffs):
            features[f'wavelet_E_{i}'] = float(np.sum(np.array(c) ** 2))
    except Exception:
        for i in range(5):
            features[f'wavelet_E_{i}'] = 0.0

    return features


# =====================================================================
# INICIALIZACIÓN Y RUTAS WEBUI
# =====================================================================
ui = WebUI()


# ── Helper: dict de error con step + traceback completo ──────────────
def _err(message, step=None, exc=None):
    payload = {"status": "error", "message": message}
    if step:
        payload["step"] = step
    if exc is not None:
        payload["traceback"]      = tb.format_exc()
        payload["exception_type"] = type(exc).__name__
        payload["exception_str"]  = str(exc)
    return payload


# ── Ping / diagnóstico ────────────────────────────────────────────────
def _try_version(module_name: str) -> str:
    """Importa el módulo y devuelve su versión, o un mensaje de no-instalado."""
    try:
        mod = __import__(module_name)
        return getattr(mod, "__version__", "instalado (sin __version__)")
    except Exception:
        return "NO instalado"


async def ping_endpoint():
    import sys
    sklearn_ver  = _try_version("sklearn")
    xgboost_ver  = _try_version("xgboost")
    lightgbm_ver = _try_version("lightgbm")

    # Lista de modelos que este Arduino puede deserializar
    supported = ["rf", "svm"]   # rf y svm vienen con sklearn
    if "NO instalado" not in xgboost_ver:  supported.append("xgb")
    if "NO instalado" not in lightgbm_ver: supported.append("lgbm")

    return {
        "status":   "ok",
        "message":  "Backend activo",
        "python":   sys.version,
        "numpy":    np.__version__,
        "pandas":   pd.__version__,
        "joblib":   joblib.__version__,
        "sklearn":  sklearn_ver,
        "xgboost":  xgboost_ver,
        "lightgbm": lightgbm_ver,
        "supported_models": supported,
    }


# ── Análisis principal ────────────────────────────────────────────────
async def analyze_endpoint(
    model_file: UploadFile = File(...),
    csv_file:   UploadFile = File(...),
):
    logger.info("Recibiendo archivos vía Multipart FormData...")
    step = "inicio"
    try:
        # 1. Leer bytes
        step = "lectura_bytes_modelo"
        try:
            model_bytes = await model_file.read()
        except Exception as e:
            return _err(f"No se leyeron bytes del modelo: {e}", step=step, exc=e)

        step = "lectura_bytes_csv"
        try:
            csv_bytes = await csv_file.read()
        except Exception as e:
            return _err(f"No se leyeron bytes del CSV: {e}", step=step, exc=e)

        logger.info(f"Tamaños → modelo: {len(model_bytes)} B | csv: {len(csv_bytes)} B")
        if len(model_bytes) == 0:
            return _err("El .joblib recibido tiene 0 bytes.", step=step)
        if len(csv_bytes) == 0:
            return _err("El .csv recibido tiene 0 bytes.", step=step)

        # 2. Cargar modelo
        step = "carga_modelo"
        try:
            model_data = joblib.load(io.BytesIO(model_bytes))
        except ModuleNotFoundError as e:
            missing = str(e).split("'")[1] if "'" in str(e) else str(e)
            hints = {
                "sklearn":  "pip install scikit-learn",
                "xgboost":  "pip install xgboost",
                "lightgbm": "pip install lightgbm",
            }
            hint = hints.get(missing)
            msg = (f"El .joblib requiere la librería '{missing}', "
                   f"pero NO está instalada en este Arduino.")
            if hint:
                msg += f"  SOLUCIÓN: en el Arduino ejecuta '{hint}' y reinicia el backend."
            return _err(msg, step=step, exc=e)
        except Exception as e:
            return _err(f"joblib no pudo deserializar el archivo: {e}", step=step, exc=e)

        # 3. Extraer componentes (RF, SVM, XGB, LGBM, scaler, feature_names)
        # Soporta 4 modelos. Acepta tanto un dict raíz {rf, svm, xgb, lgbm}
        # como un envoltorio {'models': {...}}.
        MODEL_KEYS = ('rf', 'svm', 'xgb', 'lgbm')
        if isinstance(model_data, dict):
            md = model_data.get('models') if isinstance(model_data.get('models'), dict) else {}
            loaded_models = {
                k: (md.get(k) or model_data.get(k))
                for k in MODEL_KEYS
                if (md.get(k) is not None) or (model_data.get(k) is not None)
            }
            scaler    = model_data.get('scaler')
            f_names   = model_data.get('feature_names')
            logger.info(f"Claves del .joblib: {list(model_data.keys())}")
        else:
            # El .joblib es directamente un modelo (formato muy antiguo) → asumir RF
            loaded_models = {'rf': model_data}
            scaler  = None
            f_names = None
            logger.info(f"El .joblib ES el modelo: {type(model_data).__name__}")

        if not loaded_models:
            keys = list(model_data.keys()) if isinstance(model_data, dict) else str(type(model_data))
            return _err(
                f"No se encontró ningún modelo ({', '.join(MODEL_KEYS)}) en el .joblib. "
                f"Claves disponibles: {keys}",
                step=step
            )

        logger.info(
            "Modelos → "
            + " | ".join(f"{k.upper()}: {'sí' if k in loaded_models else 'no'}" for k in MODEL_KEYS)
            + f" | Scaler: {'sí' if scaler is not None else 'no'}"
        )

        # 4. Parsear CSV
        step = "parseo_csv"
        try:
            csv_text = csv_bytes.decode('utf-8', errors='replace')
            df = pd.read_csv(io.StringIO(csv_text))
        except Exception as e:
            return _err(f"pandas no pudo leer el CSV: {e}", step=step, exc=e)

        logger.info(f"CSV shape: {df.shape} | columnas: {list(df.columns)}")
        if df.shape[1] < 2:
            return _err(
                f"CSV con {df.shape[1]} columna(s). Necesita ≥2. Columnas: {list(df.columns)}",
                step=step
            )

        # 5. Detectar columnas
        step = "deteccion_columnas"
        cols_lower = [c.lower() for c in df.columns]
        col_t_name = next((df.columns[i] for i, c in enumerate(cols_lower) if 't' in c or 'time' in c), df.columns[0])
        col_p_name = next((df.columns[i] for i, c in enumerate(cols_lower) if 'p' in c or 'pres' in c or 'bar' in c), df.columns[1])
        logger.info(f"Tiempo→'{col_t_name}' | Presión→'{col_p_name}'")

        try:
            t = df[col_t_name].to_numpy(dtype=float)
            p = df[col_p_name].to_numpy(dtype=float)
        except Exception as e:
            return _err(
                f"No se pudo convertir a float. Tiempo='{col_t_name}', Presión='{col_p_name}': {e}",
                step=step, exc=e
            )

        if len(t) < 10:
            return _err(f"Señal muy corta: {len(t)} muestras (mínimo 10).", step=step)

        # 6. Calcular fs
        step = "calculo_fs"
        diffs = np.diff(t)
        valid = diffs[diffs > 0]
        dt = float(np.median(valid)) if len(valid) > 0 else 1e-3
        fs = max(1, int(round(1.0 / dt)))
        logger.info(f"fs={fs} Hz | n={len(t)}")

        # 7. Extraer características
        step = "extraccion_features"
        try:
            feats = extract_features(t, p, fs)
        except Exception as e:
            return _err(f"Error al extraer características: {e}", step=step, exc=e)

        # 8. Construir X
        step = "construccion_X"
        if f_names:
            missing = [k for k in f_names if k not in feats]
            if missing:
                return _err(f"Faltan {len(missing)} features: {missing[:10]}", step=step)
            X = np.array([feats[k] for k in f_names], dtype=float).reshape(1, -1)
        else:
            X = np.array(list(feats.values()), dtype=float).reshape(1, -1)

        # 9. Aplicar scaler
        if scaler is not None:
            step = "scaler_transform"
            try:
                X = scaler.transform(X)
            except Exception as e:
                return _err(f"Error en scaler.transform(): {e}", step=step, exc=e)

        # 10. Predecir con cada modelo disponible
        step = "prediccion"

        def _run_model(model, X):
            """Predice con un modelo de sklearn-like (RF/SVM/XGB/LGBM).
               Devuelve (pred_class, conf_in_predicted_class, prob_bypass)."""
            pred = int(model.predict(X)[0])
            conf = 100.0
            prob_bypass = float(pred)  # fallback si no hay predict_proba
            if hasattr(model, 'predict_proba'):
                try:
                    probs   = model.predict_proba(X)[0]
                    classes = list(model.classes_)
                    # prob_bypass = probabilidad de la clase 1
                    if 1 in classes:
                        prob_bypass = float(probs[classes.index(1)])
                    else:
                        prob_bypass = float(pred)
                    # confianza en la clase predicha
                    idx  = classes.index(pred) if pred in classes else pred
                    conf = round(float(probs[idx]) * 100, 2)
                except Exception as e:
                    logger.warning(f"predict_proba falló en {type(model).__name__}: {e}")
            return pred, conf, prob_bypass

        results = {}
        try:
            for key, model in loaded_models.items():
                pred, conf, pbp = _run_model(model, X)
                results[key] = {
                    "prediction":  pred,
                    "label":       "BYPASS" if pred == 1 else "NORMAL",
                    "confidence":  conf,
                    "prob_bypass": round(pbp * 100, 2),
                }
        except Exception as e:
            return _err(f"Predicción falló: {e}", step=step, exc=e)

        if not results:
            return _err("Ningún modelo pudo predecir.", step=step)

        # 11. Voting ensemble (soft voting): promedio de prob_bypass
        n_models     = len(results)
        ensemble_pbp = sum(r["prob_bypass"] for r in results.values()) / n_models  # [0..100]
        ensemble_pred = 1 if ensemble_pbp >= 50.0 else 0
        ensemble_label = "BYPASS" if ensemble_pred == 1 else "NORMAL"
        # Confianza = % en la clase elegida por el ensemble
        ensemble_conf = round(ensemble_pbp if ensemble_pred == 1 else (100.0 - ensemble_pbp), 2)
        ensemble_pbp  = round(ensemble_pbp, 2)

        # ¿Coinciden todos los modelos? (informativo, no se muestra grande)
        all_preds = {r["prediction"] for r in results.values()}
        agreement = (len(all_preds) == 1) if n_models > 1 else None

        summary = " · ".join(
            f"{k.upper()}: {v['label']} ({v['confidence']}%)"
            for k, v in results.items()
        )
        logger.info(
            f"==> ENSEMBLE [{ensemble_label} {ensemble_conf}% | "
            f"P(bypass)={ensemble_pbp}% | n={n_models}] · {summary}"
        )

        return {
            "status":         "success",
            # Veredicto principal = ensemble
            "prediction":     ensemble_pred,
            "label":          ensemble_label,
            "confidence":     ensemble_conf,
            "prob_bypass":    ensemble_pbp,
            "agreement":      agreement,
            "n_models":       n_models,
            "models":         results,
            "fs_hz":          fs,
            "n_samples":      len(t),
        }

    except Exception as e:
        logger.exception(f"Excepción no controlada en paso '{step}': {e}")
        return _err(f"Error inesperado en paso '{step}': {e}", step=step, exc=e)


# ── Inspección de modelo (para que el frontend muestre qué IA hay) ────
async def inspect_model_endpoint(model_file: UploadFile = File(...)):
    """Inspecciona un .joblib y devuelve qué modelos contiene (RF/SVM),
       sin ejecutar predicción. Útil para que la UI muestre un indicador
       apenas se cargue el archivo, antes de subir el CSV."""
    step = "inicio"
    try:
        step = "lectura_bytes"
        try:
            model_bytes = await model_file.read()
        except Exception as e:
            return _err(f"No se leyeron bytes del modelo: {e}", step=step, exc=e)

        if len(model_bytes) == 0:
            return _err("El .joblib recibido tiene 0 bytes.", step=step)

        step = "carga_modelo"
        try:
            model_data = joblib.load(io.BytesIO(model_bytes))
        except Exception as e:
            return _err(f"joblib no pudo deserializar el archivo: {e}", step=step, exc=e)

        step = "inspeccion"
        MODEL_KEYS = ('rf', 'svm', 'xgb', 'lgbm')
        if isinstance(model_data, dict):
            md = model_data.get('models') if isinstance(model_data.get('models'), dict) else {}
            present = {
                k: ((md.get(k) or model_data.get(k)) is not None)
                for k in MODEL_KEYS
            }
            scaler  = model_data.get('scaler')
            f_names = model_data.get('feature_names')
        else:
            # joblib sin envoltorio → asumir RF
            present = {'rf': True, 'svm': False, 'xgb': False, 'lgbm': False}
            scaler  = None
            f_names = None

        models_found = [k for k, v in present.items() if v]
        if not models_found:
            return _err(
                f"El .joblib no contiene ninguno de: {', '.join(MODEL_KEYS)}.",
                step=step
            )

        label = "+".join(m.upper() for m in models_found)

        logger.info(
            f"🔍 Modelo inspeccionado: {label} "
            f"(n={len(models_found)}) | scaler={'sí' if scaler is not None else 'no'}"
        )

        return {
            "status":     "success",
            "has_rf":     present['rf'],
            "has_svm":    present['svm'],
            "has_xgb":    present['xgb'],
            "has_lgbm":   present['lgbm'],
            "has_scaler": scaler is not None,
            "models":     models_found,
            "n_models":   len(models_found),
            "label":      label,
            "n_features": len(f_names) if f_names else None,
            "size_bytes": len(model_bytes),
        }

    except Exception as e:
        logger.exception(f"Excepción en inspect_model paso '{step}': {e}")
        return _err(f"Error inesperado en paso '{step}': {e}", step=step, exc=e)


# Registrar las APIs
ui.expose_api("GET",  "/api/ping",          ping_endpoint)
ui.expose_api("POST", "/api/analyze",       analyze_endpoint)
ui.expose_api("POST", "/api/inspect_model", inspect_model_endpoint)

logger.info("=" * 60)
logger.info("Sistema IA iniciado.")
logger.info("Soporta .joblib con RF / SVM / XGB / LGBM (requiere sklearn).")
logger.info("Voting ensemble: promedio de probabilidades P(BYPASS) por modelo.")
logger.info("=" * 60)

App.run()